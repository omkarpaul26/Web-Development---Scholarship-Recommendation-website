from django.contrib import admin
from home.models import *
# Register your models here.
admin.site.register(Contact)
admin.site.register(Scholarship)
admin.site.register(Profile)
admin.site.register(FieldOfInterest)
admin.site.register(Feedback)
admin.site.register(Institute)
admin.site.register(Program)
admin.site.register(TypeOfDegree)
admin.site.register(History)
admin.site.register(Country)
